class Question:
     def __init__(self, prompt, options, answer):
          self.prompt = prompt
          self.options = options
          self.answer = answer

questions_list = [
     Question("Which African country was formerly known as Abyssinia?\n","(a) Syria (b)Eygpt (c) Jordan (d) Ethiopia\n", "d"),
     Question("Tennis star Serena Williams won which major tournament while pregnant with her first child?\n","(a) Wimbeldon (b) Australian Open (c) French Open (d)U.S. Open\n", "b"),
     Question("Fissures, vents and plugs are all associated with which geological feature?\n","(a) Volcanoes (b) Craters (c) Geysers (d) Mountains\n", "a"),
     Question("Which country consumes the most chocolate per capita?\n","(a) England (b) Switzerland (c) United States (d) Brazil\n", "b"),
     Question("What is the loudest animal on Earth?\n","(a) Lion (b) Blue Whale (c) Sperm Whale (d) Tiger Pistol Shrimp\n", "d"),
     Question("What is the world’s biggest island?\n","(a) Australia (b) New Guinea (c) Greenland (d) Norway\n", "c"),
     Question("Which country is known as the Land of White Elephant?\n","(a) India (b) Botswana (c) Vietnam (d) Thailand\n", "d"),
     Question("What colour is a Himalayan poppy?\n","(a) Yellow (b) Blue (c) Red (d) Brown\n", "b"),
     Question("When did the Cold War end?\n","(a) 1989 (b) 1984 (c) 1986 (d) 1985\n", "a"),
     Question("When did Margaret Thatcher become Prime Minister?\n","(a) 1989 (b) 1789 (c) 1975 (d) 1979\n", "d"),
     Question("What country won the very first FIFA World Cup in 1930?\n","(a) France (b) Italy (c) Uruguay (d) Argentina\n", "c"),
     Question("What flavour is Cointreau?\n","(a) Pineapple (b) Orange (c) Lemon (d) Strawberry\n", "b"),
     Question("In which country is the Kalahari Desert?\n","(a) Botswana (b)Algeria (c) Sudan (d) Saudi Arabia\n", "a"),
     Question("How many eyes does a bee have?\n", "(a) Five (b) Six (c) Three (d) None\n", "a"),
     Question("Which country produces the most coffee in the world?\n","(a) Ivory Coast (b) Ghana (c) Ethiopia (d) Brazil\n", "d"),
     Question("Which name is rapper Sean Combs better known by?\n", "(a)Jay-Z (b) P.diddy (c) Drake (d) Tupac\n", "b"),
     Question("Which bone are babies born without?\n", "(a) Fibula (b) Hip-bones (c) Knew-caps (d) Clavicle\n", "c"),
     Question("How many hearts does an octopus have?\n","(a) Five (b) Two (c) Three (d) One\n", "c"),
]

answer_entries = 'abcdABCD'
question_number = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15",]
