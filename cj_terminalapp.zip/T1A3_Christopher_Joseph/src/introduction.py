import time
import qlist
import random
import sys

def intro():
   print("Welcome to QuickTrivia\nYour Easy Trivia Pastime\n")
   time.sleep(1)
   print("To play you will enter the number of questions you would like answer\n")
   time.sleep(3)
   print("Be sure to only enter A/B/C/D to select an option")
   time.sleep(3)
   print("Type: Exit to leave the game at any time")
   time.sleep(3)
   print("READY...")
   time.sleep(2)
   print("HOLD ON NOW THINK CAREFULLY")
   time.sleep(2)
   print("YOU ONLY HAVE 2 INCORRECT ATTEMPTS IF YOU LOSE THEM ALL THAT'S IT!")
   time.sleep(4)
   print("Lets go!")
   time.sleep(2)
