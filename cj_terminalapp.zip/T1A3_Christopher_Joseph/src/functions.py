import qlist
import sys

def asking_question(question):
    answer = input(f"{question.prompt}{question.options}")
    if answer == "Exit" or answer == "EXIT" or answer == "exit":
       sys.exit()
    else:
        while answer not in qlist.answer_entries or answer == "":
            print("..............a/b/c/d entries only(uppercase allowed).......")
            print("...................let's try that again..............\n") 
            answer = input(f"{question.prompt}{question.options}") 
            if answer == "Exit" or answer == "EXIT" or answer == "exit":
                sys.exit()
    return answer

def correct(score, counter):
   print("That's CORRECT")

def incorrect(counter, attempts):
   print("That's INCORRECT")

