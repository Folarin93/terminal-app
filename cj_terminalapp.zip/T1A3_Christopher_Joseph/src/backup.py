#!/usr/sbin/python

import time
import qlist
import random
import sys


from functions import correct, incorrect, asking_question

def intro():
   print("Welcome to QuickTrivia\nYour Easy Trivia Pastime\n")
   time.sleep(1)
   print("To play you will enter the number of questions you would like answer\n")
   time.sleep(3)
   print("Be sure to only enter A/B/C/D to select an option")
   time.sleep(3)
   print("Type: Exit to leave the game at any time")
   time.sleep(3)
   print("READY...")
   time.sleep(2)
   print("HOLD ON NOW THINK CAREFULLY")
   time.sleep(2)
   print("YOU ONLY HAVE 2 INCORRECT ATTEMPTS IF YOU LOSE THEM ALL THAT'S IT!")
   time.sleep(4)
   print("Lets go!")
   time.sleep(2)

def run_quiz(questions_list):
   number_questions = input("How many questions (Max.15)?\n")
   while number_questions not in qlist.question_number:
      if number_questions == "Exit" or number_questions == "EXIT" or number_questions == "exit":
       sys.exit()
      else:
         number_questions = input("INVALID ENTRY!,How many questions(Max.15)?\n")

   no_questions = int(number_questions)
   attempts = 2 
   counter = 0
   score = 0
   
   while counter < no_questions and attempts != 0: 
      question = random.choice(qlist.questions_list) 
      qlist.questions_list.remove(question)
      answer = asking_question(question) 
      if answer == question.answer.lower() or answer == question.answer.upper():
         correct(score, counter)
         score += 1
         counter += 1
      else:
         incorrect(counter, attempts)
         attempts -= 1
         counter += 1
   print("You Scored", score, "out of", no_questions)


intro()
cont = "y"
while cont == "y":
   run_quiz(qlist.questions_list)
   cont = input("Do you want to play again? y/n\n")
